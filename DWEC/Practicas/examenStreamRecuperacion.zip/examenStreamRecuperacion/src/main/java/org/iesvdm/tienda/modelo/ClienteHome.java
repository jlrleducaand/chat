package org.iesvdm.tienda.modelo;
// Generated 3 dic 2023 12:28:04 by Hibernate Tools 5.6.15.Final

/**
 * Home object for domain model class Cliente.
 * @see Cliente
 * @author Hibernate Tools
 */
public class ClienteHome extends AbstractHome<Cliente> {

}
