package org.iesvdm.tienda.modelo;
// Generated 3 dic 2023 12:28:04 by Hibernate Tools 5.6.15.Final

/**
 * Home object for domain model class Pedido.
 * @see Pedido
 * @author Hibernate Tools
 */
public class PedidoHome extends AbstractHome<Pedido>{

}
