package p1.modelo;

public enum Status {

    PaymentComplete, Pending

}
