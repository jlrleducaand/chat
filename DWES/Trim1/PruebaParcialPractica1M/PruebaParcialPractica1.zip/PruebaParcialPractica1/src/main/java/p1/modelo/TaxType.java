package p1.modelo;

public enum TaxType {

    General, Reduced, SuperReduced
}
